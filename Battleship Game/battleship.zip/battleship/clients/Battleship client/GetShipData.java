/**
 * Write a description of class GetShipData here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface GetShipData  
{
    public int getTarget();
    public int getNumber();
}
