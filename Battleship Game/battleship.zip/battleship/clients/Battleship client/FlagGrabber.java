import java.util.ArrayList;

public class FlagGrabber implements Subject
{
    private ArrayList<Observer> observers;
    private boolean flag;
    
    public FlagGrabber(){
        observers=new ArrayList<Observer>();
    }
    
    public void register(Observer newObserver){
        observers.add(newObserver);
    }
    
    public void unregister(Observer deleteObserver){
        int index=observers.indexOf(deleteObserver);
        System.out.println("observer"+(index+1)+"deleted");
        observers.remove(index);
    }
    
    public void notifyObserver(){
        for(Observer observer:observers){
            observer.update(flag);
        }
    }
    
    public void setFlag(boolean f){
        this.flag=f;
        notifyObserver();
    }
    
}
