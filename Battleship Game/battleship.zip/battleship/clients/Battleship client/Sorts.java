
public interface Sorts  
{
    void sort(int[] arr);
}

class ItSorts implements Sorts{
    
    public void sort(int[] arr){
        java.util.Arrays.sort(arr);
    }
}

class ItNotSorts implements Sorts{
    public void sort(int[] arr){
        //not sort
    }
}
