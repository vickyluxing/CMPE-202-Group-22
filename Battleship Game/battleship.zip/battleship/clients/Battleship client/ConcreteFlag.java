
public abstract class ConcreteFlag  
{
    private boolean flag;
    
    public void setFlag(boolean f){
        this.flag=f;
    }
    
    public boolean getFlag(){
        return flag;
    }
}
