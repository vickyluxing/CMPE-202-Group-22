
public class FlagFalse  extends ConcreteFlag
{
    public FlagFalse(){
        setFlag(false);
    }
}
