
public class FlagFactory  
{
    public ConcreteFlag makeFlag(){
        return new FlagTrue();
    }
    
}
