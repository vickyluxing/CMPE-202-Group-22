
public class PlayerObserver implements Observer
{
    
    private boolean flag=false;
    private Subject flagGrabber;
    
    
    public PlayerObserver(Subject flagGrabber)
    {
        this.flagGrabber=flagGrabber;
    }

    public void update(boolean f){
        this.flag=f;
        printFlag();
    }
    
    public void printFlag(){
        if(flag==true){
            System.out.println("player blue's turn.");
        }else{
            System.out.println("player black's turn.");
        }
    }
}
