
public class FlagTrue extends ConcreteFlag 
{
    public FlagTrue(){
        setFlag(true);
    }
}
