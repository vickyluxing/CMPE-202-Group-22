
public class ArrHolder  
{
    int[] arr;
    public Sorts sortType;
    
    public ArrHolder(int[] n){
        this.arr=n;
        sortType=new ItSorts();
    }
    
    public void tryToSort(){
        sortType.sort(arr);
    }
    
}
