package battleship;

public interface Command
{
    
    public int execute();
}
