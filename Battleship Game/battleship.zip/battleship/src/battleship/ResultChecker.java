package battleship;


public class ResultChecker {
    
    private int target=0;
    private String result="";
    private static ResultChecker theChecker;

    public static ResultChecker getInstance(){
        if(theChecker==null){
            theChecker=new ResultChecker();
            return theChecker;
        }else{
            return theChecker;
        }
    }

    public int getTarget() {
        return this.target;
    }

    public void setTarget(int n) {
        this.target = n;
    }

    public String getResult() {
        return this.result;
    }

    public void setResult(String res) {
        this.result = res;
    }

    public String toString() {
		StringBuffer result = new StringBuffer();
		result.append("\ntarget: " + target + "");
        result.append("\nresult: " + result + "");
		result.append("\n");
		return result.toString();
	}

}
