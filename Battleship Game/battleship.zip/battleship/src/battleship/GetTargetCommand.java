package battleship;

public class GetTargetCommand implements Command
{
    ResultChecker rc;

    public GetTargetCommand(ResultChecker resChecker)
    {
        // initialise instance variables
        this.rc=resChecker;
    }

    public int execute(){
        return rc.getTarget();
    }
}
