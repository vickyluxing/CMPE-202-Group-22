package api ;

import org.json.* ;
import org.restlet.representation.* ;
import org.restlet.ext.json.* ;
import org.restlet.resource.* ;
import battleship.ResultChecker ;
import battleship.*;

public class BattleshipResource extends ServerResource {

   // GumballMachine machine = GumballMachine.getInstance() ;
   int target = 0;
   ResultChecker rc = ResultChecker.getInstance() ;

    @Get
    public Representation get() throws JSONException {

        // String banner = machine.toString() ;
        // int count = machine.getCount() ;
        // String state = machine.getStateString() ;
        int target = rc.getTarget();
        //command pattern line
        // SimpleRemoteControl remote = new SimpleRemoteControl();
        // ResultChecker rc=new ResultChecker();
        // GetTargetCommand getTarget=new GetTargetCommand(rc);
        // remote.setCommand(getTarget);
        // int target = remote.buttonWasPressed();

        String result = rc.getResult();
        JSONObject json = new JSONObject() ;
        // json.put( "banner", banner ) ;
        // json.put( "count", count ) ;
        // json.put( "state", state ) ;
        json.put("target",target);
        json.put("result",result);
        return new JsonRepresentation ( json ) ;
    }


    @Post
    public Representation post(JsonRepresentation jsonRep) {

        JSONObject json = jsonRep.getJsonObject() ;
        String type = json.getString("type") ;
        Integer temp = json.getInt("number");
        System.out.println( "type: " + type ) ;

        if ( type.equals( "target") )
            //machine.insertQuarter() ;
            //this.target = temp;
            rc.setTarget(temp);
            rc.setResult("");
        if ( type.equals( "blue") ) {
            if(temp == rc.getTarget()) {
                rc.setResult("blue");
            }
        }
        if( type.equals("black")) {
            if(temp == rc.getTarget()) {
                rc.setResult("black");
            }
        }
            //machine.turnCrank();


        JSONObject response = new JSONObject() ;
        int target = rc.getTarget();
        String result = rc.getResult() ;
        response.put("target",target);
        response.put( "result", result ) ;

        return new JsonRepresentation ( response ) ;

    }
}

