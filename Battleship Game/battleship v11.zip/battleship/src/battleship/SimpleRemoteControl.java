package battleship;


public class SimpleRemoteControl
{
    // instance variables - replace the example below with your own
    Command slot;

    /**
     * Constructor for objects of class SimpleRemoteControl
     */
    public SimpleRemoteControl() {}

    public void setCommand (Command command)
    {
        slot = command;
    }
    
    public int buttonWasPressed() {
        return slot.execute();
    }
}
