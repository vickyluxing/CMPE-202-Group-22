import org.json.JSONObject ;
import org.restlet.resource.*;
import org.restlet.representation.* ;
import org.restlet.ext.json.* ;
import org.restlet.data.* ;


public class Battleship  
{
    // instance variables - replace the example below with your own
    private String URL = "http://localhost:8080/battleship" ;
    //http://localhost:8080/battleship 

    ClientResource client ; 

    public Battleship()
    {
        client=new ClientResource(URL);
    }
    
    public boolean blueClick(int n) throws Exception{
        JSONObject json_blue_click = new JSONObject();
        json_blue_click.put("type", "blue");
        json_blue_click.put("number", n);
        JsonRepresentation jrep = new JsonRepresentation (
        client.post(new JsonRepresentation(json_blue_click), MediaType.APPLICATION_JSON));
        JSONObject json_res = jrep.getJsonObject();
        String res = json_res.getString("result");
        System.out.println("result: "+res+"");
        if(res.equals("blue")) {
            // blue wins
            System.out.println("blue wins1");
            return true;
        }else {
            System.out.println("not yet");
            return false;
        }
    }
    
    public boolean blackClick(int n) throws Exception{
        JSONObject json_black_click = new JSONObject();
        json_black_click.put("type", "black");
        json_black_click.put("number", n);
        JsonRepresentation jrep = new JsonRepresentation(
        client.post(new JsonRepresentation(json_black_click), MediaType.APPLICATION_JSON));
        JSONObject json_res = jrep.getJsonObject();
        String res = json_res.getString("result");
        System.out.println("result: "+res+"");
        if(res.equals("black")) {
            // black wins
            System.out.println("black wins1");
            return true;
        }else return false;
    }
    
    public void sendTarget(int n) throws Exception{
        JSONObject json_target = new JSONObject();
        json_target.put("type", "target");
        json_target.put("number", n);
        JsonRepresentation jrep = new JsonRepresentation(
        client.post(new JsonRepresentation(json_target), MediaType.APPLICATION_JSON));
        JSONObject json_res = jrep.getJsonObject();
    }
    
    public String toString() {
        String result = "" ;
        Representation result_string = client.get() ; //get method response from server
        try {
          JSONObject json = new JSONObject( result_string.getText() ) ;
          result = (String) json.get("banner") ;
        }
        catch (Exception e) {
          result = e.getMessage() ;
        }          
        return result ;
  }
        
}
