
public interface Observer  
{
    public void update(boolean flag);
}
