import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class BattleshipBlue extends Actor implements GetShipData
{
   
    int number;
    int answer;
   // int key=0;
    
    public BattleshipBlue(int x,int ans){
        this.number=x;
        this.answer=ans;
    }
    
    public int getTarget(){
        return this.answer;
    }
    
    public int getNumber(){
        return this.number;
    }
    
    public void act()
    {
        // Add your action code here.
   
            if(Greenfoot.mouseClicked(this)){
                if(LogicCore.flag==true){
                    Battleship battleship=new Battleship();
                    boolean flag=false;
                    //observer pattern
                    FlagGrabber flagGrabber=new FlagGrabber();
                    PlayerObserver observer1=new PlayerObserver(flagGrabber);
                    flagGrabber.setFlag(flag);
                    //battleship.blueClick(this.number);
                    //if(this.number==this.answer) key=1;
                    World world=getWorld();
                    world.showText(""+this.number+"",this.getX(),this.getY());
                    world.removeObject(this);
                    Greenfoot.playSound("blast.wav");
                    try{
                        //battleship.blueClick(this.number);
                        System.out.println(flag);
                        if(battleship.blueClick(this.number)) {
                            world.showText("Blue win",200,200);
                            Greenfoot.playSound("Player1.mp3");
                            Greenfoot.delay(150);
                            Greenfoot.setWorld(new ScoreBoard());
                        }
                    }catch (Exception e){
                        
                    }
           
                    
                    LogicCore.flag=false;
                }
            
            };   
        
    }    
    
    
}
