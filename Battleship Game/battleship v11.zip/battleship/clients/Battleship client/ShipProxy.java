
public class ShipProxy  implements GetShipData
{
    public int getTarget(){
        BattleshipBlue bb=new BattleshipBlue(1,2);
        return bb.getTarget();
    }
    
    public int getNumber(){
        BattleshipBlue bb=new BattleshipBlue(1,2);
        return bb.getNumber();
    }
}
