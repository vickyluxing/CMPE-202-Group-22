package battlesrc;


public class Battleship
{
    // instance variables - replace the example below with your own
    

    public Battleship()
    {
        // initialise instance variables
        x = 0;
    }

}
